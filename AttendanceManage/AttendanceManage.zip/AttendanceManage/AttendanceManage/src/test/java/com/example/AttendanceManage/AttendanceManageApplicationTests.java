package com.example.AttendanceManage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AttendanceManageApplicationTests {

	@Test
	void contextLoads() {
	}

}
